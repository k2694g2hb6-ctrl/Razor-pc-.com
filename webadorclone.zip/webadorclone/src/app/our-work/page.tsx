'use client';

import React, { useState } from 'react';

export default function OurWorkPage() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const projects = [
  {
    title: 'Apex Gaming Brand Launch',
    category: 'Brand Identity',
    description:
    'Developed a full brand identity for a rising gaming peripheral company, including logo design, color system, and visual guidelines that resonated with the competitive gaming community.',
    image: "https://img.rocket.new/generatedImages/rocket_gen_img_1bd2e63b3-1772433146654.png",
    alt: 'Designer working on brand identity materials with colorful artwork spread across a desk'
  },
  {
    title: 'NexGen PC Social Campaign',
    category: 'Social Media Marketing',
    description:
    'Executed a multi-platform social media campaign for a custom PC builder, growing their Instagram following by 300% and driving a significant increase in online inquiries.',
    image: "https://img.rocket.new/generatedImages/rocket_gen_img_1dc5c2831-1772290396578.png",
    alt: 'Abstract blue digital wave pattern representing digital marketing campaign visuals'
  },
  {
    title: 'RigMaster SEO Overhaul',
    category: 'SEO & Digital Advertising',
    description:
    'Redesigned the SEO strategy for a PC hardware retailer, resulting in a 150% increase in organic traffic and top-3 rankings for key product search terms within six months.',
    image: "https://images.unsplash.com/photo-1718777025831-5cb28feb8518",
    alt: 'Gaming PC setup with RGB lighting showcasing high-performance hardware build'
  },
  {
    title: 'PixelForge Content Series',
    category: 'Content Creation',
    description:
    'Produced a 12-part video and blog content series for a gaming accessories brand, establishing them as a thought leader in the PC enthusiast space and boosting engagement by 200%.',
    image: "https://img.rocket.new/generatedImages/rocket_gen_img_11ba60dc7-1772888679548.png",
    alt: 'Creative workspace with marketing materials and design tools laid out on a table'
  },
  {
    title: 'VoltEdge Email Campaign',
    category: 'Email Marketing',
    description:
    'Designed and launched a segmented email marketing campaign for a gaming monitor brand, achieving a 45% open rate and a 20% conversion rate on their new product launch.',
    image: "https://img.rocket.new/generatedImages/rocket_gen_img_1a27486c1-1765280180943.png",
    alt: 'Digital communication concept with blue abstract background representing email outreach'
  },
  {
    title: 'CoreTech Website Redesign',
    category: 'Web Design & Development',
    description:
    'Rebuilt the website for a PC components distributor from the ground up — delivering a fast, mobile-first experience that reduced bounce rate by 40% and doubled online sales.',
    image: "https://images.unsplash.com/photo-1714424891654-35351a9d1bff",
    alt: 'Modern gaming PC build with illuminated components representing high-performance web development'
  }];


  return (
    <div className="min-h-screen" style={{ backgroundColor: '#f9f9f9', fontFamily: "'Roboto', sans-serif" }}>
      {/* Header */}
      <header className="razor-header">
        <div className="razor-header-inner">
          {/* Logo */}
          <a href="/" className="razor-logo">
            Razor PC
          </a>

          {/* Desktop Navigation */}
          <nav className="razor-nav hidden md:block">
            <ul>
              <li>
                <a href="/" className="razor-nav-link">Home</a>
              </li>
              <li>
                <a href="/our-services" className="razor-nav-link">Our Services</a>
              </li>
              <li>
                <a href="/our-work" className="razor-nav-link active">Our Work</a>
              </li>
            </ul>
          </nav>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden flex flex-col gap-1.5 p-2"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            aria-label="Toggle menu">

            <span className="block w-6 h-0.5 bg-gray-700"></span>
            <span className="block w-6 h-0.5 bg-gray-700"></span>
            <span className="block w-6 h-0.5 bg-gray-700"></span>
          </button>
        </div>

        {/* Mobile Navigation */}
        {mobileMenuOpen &&
        <nav className="md:hidden bg-white border-t border-gray-100">
            <ul className="flex flex-col">
              <li>
                <a
                href="/"
                className="block px-6 py-3 text-sm font-normal uppercase border-b border-gray-100"
                style={{ fontFamily: "'Roboto', sans-serif", color: '#000' }}>

                  Home
                </a>
              </li>
              <li>
                <a
                href="/our-services"
                className="block px-6 py-3 text-sm font-normal uppercase border-b border-gray-100"
                style={{ fontFamily: "'Roboto', sans-serif", color: '#000' }}>

                  Our Services
                </a>
              </li>
              <li>
                <a
                href="/our-work"
                className="block px-6 py-3 text-sm font-normal uppercase"
                style={{ fontFamily: "'Roboto', sans-serif", color: '#000', borderBottom: '2px solid #374151' }}>

                  Our Work
                </a>
              </li>
            </ul>
          </nav>
        }
      </header>
      {/* Main Content */}
      <main id="main-content">
        {/* Hero Section */}
        <section className="razor-hero" style={{ minHeight: '260px' }}>
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src="https://primary.jwwb.nl/pexels/10/10233043.jpeg"
            alt="Abstract blue digital background with wave pattern"
            className="razor-hero-image"
            loading="lazy" />

          <div className="razor-hero-backdrop"></div>
          <div className="razor-hero-content">
            <h2 className="razor-hero-heading">Our Work</h2>
            <p className="razor-hero-text">
              A showcase of our creative projects and marketing campaigns for gaming and PC brands.
            </p>
            <div className="razor-hero-spacer"></div>
          </div>
        </section>

        {/* Intro Section */}
        <section className="razor-section">
          <div className="razor-section-inner">
            <h2 className="razor-section-heading" style={{ textAlign: 'center' }}>
              Projects We&apos;re Proud Of
            </h2>
            <p className="razor-section-text" style={{ textAlign: 'center', maxWidth: '700px', margin: '0 auto' }}>
              Every project we take on is an opportunity to push creative boundaries and deliver measurable results. Here&apos;s a look at some of the work we&apos;ve done for our clients in the gaming and PC industry.
            </p>
          </div>
        </section>

        {/* Projects Grid */}
        <section className="razor-section" style={{ paddingTop: '0' }}>
          <div className="razor-section-inner">
            <div
              style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))',
                gap: '32px',
                marginTop: '16px'
              }}>

              {projects?.map((project, index) =>
              <div
                key={index}
                style={{
                  backgroundColor: '#fff',
                  borderRadius: '4px',
                  overflow: 'hidden',
                  boxShadow: '0 1px 4px rgba(0,0,0,0.07)'
                }}>

                  {/* Project Image */}
                  <div style={{ width: '100%', height: '200px', overflow: 'hidden' }}>
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                    src={project?.image}
                    alt={project?.alt}
                    loading="lazy"
                    style={{ width: '100%', height: '100%', objectFit: 'cover' }} />

                  </div>

                  {/* Project Info */}
                  <div style={{ padding: '28px 28px 32px' }}>
                    <span
                    style={{
                      display: 'inline-block',
                      fontSize: '0.75rem',
                      fontFamily: "'Montserrat', sans-serif",
                      fontWeight: '600',
                      textTransform: 'uppercase',
                      letterSpacing: '0.08em',
                      color: '#fff',
                      backgroundColor: '#374151',
                      padding: '3px 10px',
                      borderRadius: '2px',
                      marginBottom: '14px'
                    }}>

                      {project?.category}
                    </span>
                    <h3
                    style={{
                      fontFamily: "'Montserrat', sans-serif",
                      fontWeight: '700',
                      fontSize: '1.1rem',
                      color: '#374151',
                      marginBottom: '10px'
                    }}>

                      {project?.title}
                    </h3>
                    <p
                    style={{
                      fontFamily: "'Roboto', sans-serif",
                      fontSize: '0.93rem',
                      color: '#707070',
                      lineHeight: '1.7'
                    }}>

                      {project?.description}
                    </p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section
          className="razor-split-section"
          style={{ flexDirection: 'column', alignItems: 'center', textAlign: 'center', padding: '60px 24px' }}>

          <div style={{ maxWidth: '600px' }}>
            <h2 className="razor-section-heading">Let&apos;s create something great together</h2>
            <p className="razor-section-text">
              Ready to add your brand to our portfolio? We&apos;d love to hear about your project and explore how we can help you achieve your marketing goals.
            </p>
            <a
              href="/"
              style={{
                display: 'inline-block',
                marginTop: '24px',
                padding: '12px 32px',
                backgroundColor: '#374151',
                color: '#fff',
                fontFamily: "'Montserrat', sans-serif",
                fontWeight: '600',
                fontSize: '0.9rem',
                textTransform: 'uppercase',
                letterSpacing: '0.05em',
                borderRadius: '2px',
                textDecoration: 'none'
              }}>

              Back to Home
            </a>
          </div>
        </section>
      </main>
      {/* Footer */}
      <footer className="razor-footer">
        <div className="razor-footer-inner">
          <div className="razor-footer-copyright">
            &copy; 2026 Razor PC
          </div>
          <div className="razor-footer-powered">
            Powered by <a href="https://www.webador.com" rel="nofollow">Webador</a>
          </div>
        </div>
      </footer>
    </div>);

}