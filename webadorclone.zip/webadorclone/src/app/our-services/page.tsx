'use client';

import React, { useState } from 'react';

export default function OurServicesPage() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const services = [
    {
      title: 'Social Media Marketing',
      description:
        'We craft targeted social media strategies that connect your brand with the gaming and PC community. From content creation to community management, we help you build a loyal following and drive meaningful engagement across all major platforms.',
      icon: '📱',
    },
    {
      title: 'Brand Identity & Design',
      description:
        'Your brand is more than a logo — it\'s your story. We develop cohesive brand identities that resonate with your audience, including logo design, color palettes, typography, and visual guidelines that make your brand instantly recognizable.',
      icon: '🎨',
    },
    {
      title: 'Content Creation',
      description:
        'High-quality content is the backbone of any successful marketing strategy. Our team produces compelling written, visual, and video content tailored to the gaming and PC market, ensuring your message reaches and resonates with the right audience.',
      icon: '✍️',
    },
    {
      title: 'SEO & Digital Advertising',
      description:
        'Get found by the people who matter most. We optimize your online presence through strategic SEO and run data-driven paid advertising campaigns on Google, YouTube, and social platforms to maximize your reach and return on investment.',
      icon: '📈',
    },
    {
      title: 'Email Marketing',
      description:
        'Stay top-of-mind with your customers through personalized email campaigns. We design and execute email marketing strategies that nurture leads, retain customers, and drive conversions with targeted messaging and compelling calls to action.',
      icon: '📧',
    },
    {
      title: 'Web Design & Development',
      description:
        'Your website is your digital storefront. We build fast, responsive, and visually stunning websites that reflect your brand and convert visitors into customers. From landing pages to full e-commerce solutions, we\'ve got you covered.',
      icon: '💻',
    },
  ];

  return (
    <div className="min-h-screen" style={{ backgroundColor: '#f9f9f9', fontFamily: "'Roboto', sans-serif" }}>
      {/* Header */}
      <header className="razor-header">
        <div className="razor-header-inner">
          {/* Logo */}
          <a href="/" className="razor-logo">
            Razor PC
          </a>

          {/* Desktop Navigation */}
          <nav className="razor-nav hidden md:block">
            <ul>
              <li>
                <a href="/" className="razor-nav-link">Home</a>
              </li>
              <li>
                <a href="/our-services" className="razor-nav-link active">Our Services</a>
              </li>
              <li>
                <a href="/our-work" className="razor-nav-link">Our Work</a>
              </li>
            </ul>
          </nav>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden flex flex-col gap-1.5 p-2"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            aria-label="Toggle menu"
          >
            <span className="block w-6 h-0.5 bg-gray-700"></span>
            <span className="block w-6 h-0.5 bg-gray-700"></span>
            <span className="block w-6 h-0.5 bg-gray-700"></span>
          </button>
        </div>

        {/* Mobile Navigation */}
        {mobileMenuOpen && (
          <nav className="md:hidden bg-white border-t border-gray-100">
            <ul className="flex flex-col">
              <li>
                <a
                  href="/"
                  className="block px-6 py-3 text-sm font-normal uppercase border-b border-gray-100"
                  style={{ fontFamily: "'Roboto', sans-serif", color: '#000' }}
                >
                  Home
                </a>
              </li>
              <li>
                <a
                  href="/our-services"
                  className="block px-6 py-3 text-sm font-normal uppercase"
                  style={{ fontFamily: "'Roboto', sans-serif", color: '#000', borderBottom: '2px solid #374151' }}
                >
                  Our Services
                </a>
              </li>
              <li>
                <a
                  href="/our-work"
                  className="block px-6 py-3 text-sm font-normal uppercase border-b border-gray-100"
                  style={{ fontFamily: "'Roboto', sans-serif", color: '#000' }}
                >
                  Our Work
                </a>
              </li>
            </ul>
          </nav>
        )}
      </header>
      {/* Main Content */}
      <main id="main-content">
        {/* Hero Section */}
        <section className="razor-hero" style={{ minHeight: '260px' }}>
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src="https://primary.jwwb.nl/pexels/10/10233043.jpeg"
            alt="Abstract blue digital background with wave pattern"
            className="razor-hero-image"
            loading="lazy"
          />
          <div className="razor-hero-backdrop"></div>
          <div className="razor-hero-content">
            <h2 className="razor-hero-heading">Our Services</h2>
            <p className="razor-hero-text">
              Comprehensive marketing solutions designed to elevate your brand in the gaming and PC industry.
            </p>
            <div className="razor-hero-spacer"></div>
          </div>
        </section>

        {/* Services Intro */}
        <section className="razor-section">
          <div className="razor-section-inner">
            <h2 className="razor-section-heading" style={{ textAlign: 'center' }}>
              What We Offer
            </h2>
            <p className="razor-section-text" style={{ textAlign: 'center', maxWidth: '700px', margin: '0 auto' }}>
              At Razor PC, we provide a full suite of digital marketing services tailored specifically for the gaming and PC market. Whether you&apos;re a startup or an established brand, we have the expertise to help you grow.
            </p>
          </div>
        </section>

        {/* Services Grid */}
        <section className="razor-section" style={{ paddingTop: '0' }}>
          <div className="razor-section-inner">
            <div
              style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))',
                gap: '32px',
                marginTop: '16px',
              }}
            >
              {services?.map((service, index) => (
                <div
                  key={index}
                  style={{
                    backgroundColor: '#fff',
                    borderRadius: '4px',
                    padding: '36px 32px',
                    boxShadow: '0 1px 4px rgba(0,0,0,0.07)',
                    borderTop: '3px solid #374151',
                  }}
                >
                  <div style={{ fontSize: '2rem', marginBottom: '16px' }}>{service?.icon}</div>
                  <h3
                    style={{
                      fontFamily: "'Montserrat', sans-serif",
                      fontWeight: '700',
                      fontSize: '1.1rem',
                      color: '#374151',
                      marginBottom: '12px',
                    }}
                  >
                    {service?.title}
                  </h3>
                  <p
                    style={{
                      fontFamily: "'Roboto', sans-serif",
                      fontSize: '0.95rem',
                      color: '#707070',
                      lineHeight: '1.7',
                    }}
                  >
                    {service?.description}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="razor-split-section" style={{ flexDirection: 'column', alignItems: 'center', textAlign: 'center', padding: '60px 24px' }}>
          <div style={{ maxWidth: '600px' }}>
            <h2 className="razor-section-heading">Ready to grow your brand?</h2>
            <p className="razor-section-text">
              Let&apos;s work together to create a marketing strategy that drives real results for your gaming or PC brand. Reach out to us today and let&apos;s get started.
            </p>
            <a
              href="/"
              style={{
                display: 'inline-block',
                marginTop: '24px',
                padding: '12px 32px',
                backgroundColor: '#374151',
                color: '#fff',
                fontFamily: "'Montserrat', sans-serif",
                fontWeight: '600',
                fontSize: '0.9rem',
                textTransform: 'uppercase',
                letterSpacing: '0.05em',
                borderRadius: '2px',
                textDecoration: 'none',
              }}
            >
              Back to Home
            </a>
          </div>
        </section>
      </main>
      {/* Footer */}
      <footer className="razor-footer">
        <div className="razor-footer-inner">
          <div className="razor-footer-copyright">
            &copy; 2026 Razor PC
          </div>
          <div className="razor-footer-powered">
            Powered by <a href="https://www.webador.com" rel="nofollow">Webador</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
