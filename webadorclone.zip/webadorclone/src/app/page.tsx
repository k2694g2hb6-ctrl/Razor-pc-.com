'use client';

import React, { useState } from 'react';

export default function RazorPCHome() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <div className="min-h-screen" style={{ backgroundColor: '#f9f9f9', fontFamily: "'Roboto', sans-serif" }}>
      {/* Header */}
      <header className="razor-header">
        <div className="razor-header-inner">
          {/* Logo */}
          <a href="/" className="razor-logo">
            Razor PC
          </a>

          {/* Desktop Navigation */}
          <nav className="razor-nav hidden md:block">
            <ul>
              <li>
                <a href="/" className="razor-nav-link active">Home</a>
              </li>
              <li>
                <a href="/our-services" className="razor-nav-link">Our Services</a>
              </li>
              <li>
                <a href="/our-work" className="razor-nav-link">Our Work</a>
              </li>
            </ul>
          </nav>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden flex flex-col gap-1.5 p-2"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            aria-label="Toggle menu">

            <span className="block w-6 h-0.5 bg-gray-700"></span>
            <span className="block w-6 h-0.5 bg-gray-700"></span>
            <span className="block w-6 h-0.5 bg-gray-700"></span>
          </button>
        </div>

        {/* Mobile Navigation */}
        {mobileMenuOpen &&
        <nav className="md:hidden bg-white border-t border-gray-100">
            <ul className="flex flex-col">
              <li>
                <a
                href="/"
                className="block px-6 py-3 text-sm font-normal uppercase"
                style={{ fontFamily: "'Roboto', sans-serif", color: '#000', borderBottom: '2px solid #374151' }}>

                  Home
                </a>
              </li>
              <li>
                <a
                href="/our-services"
                className="block px-6 py-3 text-sm font-normal uppercase border-b border-gray-100"
                style={{ fontFamily: "'Roboto', sans-serif", color: '#000' }}>

                  Our Services
                </a>
              </li>
              <li>
                <a
                href="/our-work"
                className="block px-6 py-3 text-sm font-normal uppercase border-b border-gray-100"
                style={{ fontFamily: "'Roboto', sans-serif", color: '#000' }}>

                  Our Work
                </a>
              </li>
            </ul>
          </nav>
        }
      </header>

      {/* Main Content */}
      <main id="main-content">
        {/* Hero Section */}
        <section className="razor-hero" style={{ minHeight: '311.5px' }}>
          {/* Background Image */}
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src="https://primary.jwwb.nl/pexels/10/10233043.jpeg"
            alt="Abstract blue digital background with wave pattern"
            className="razor-hero-image"
            loading="lazy" />

          {/* Backdrop overlay */}
          <div className="razor-hero-backdrop"></div>

          {/* Content */}
          <div className="razor-hero-content">
            <h2 className="razor-hero-heading">
              Elevating your brand in the digital age
            </h2>
            <p className="razor-hero-text">
              Welcome to Razor PC, your partner in innovative marketing solutions. We are dedicated to helping businesses in Jacksonville, Florida and beyond achieve their digital potential. Discover how our strategies can drive your success.
            </p>
            {/* Spacer */}
            <div className="razor-hero-spacer"></div>
          </div>
        </section>

        {/* About Section */}
        <section className="razor-section">
          <div className="razor-section-inner">
            <div className="razor-columns">
              {/* Left Column - Text */}
              <div className="razor-column" style={{ paddingRight: '40px' }}>
                <h2 className="razor-section-heading">About Razor PC</h2>
                <p className="razor-section-text">
                  Razor PC is a great choice because it knows how to market to gaming and PC audiences in a way that feels authentic, focused, and effective. Instead of using broad, one-size-fits-all marketing, it creates strategies that speak directly to the right people and help brands stand out in a crowded space.
                </p>
              </div>

              {/* Right Column - Image */}
              <div className="razor-column">
                <div className="razor-image-wrapper">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src="https://primary.jwwb.nl/pexels/69/6913135.jpeg?enable-io=true&enable=upscale&crop=1.3333%3A1&width=800"
                    alt="Gaming PC setup with RGB lighting and cooling system"
                    loading="lazy" />

                </div>
              </div>
            </div>
          </div>
        </section>

        {/* View Our Latest Work Section */}
        <section className="razor-section">
          <div className="razor-section-inner">
            <h2 className="razor-section-heading" style={{ textAlign: 'center' }}>
              View our latest work
            </h2>
            <p className="razor-section-text" style={{ textAlign: 'center', maxWidth: '700px', margin: '0 auto' }}>
              Discover our collection of creative work and visual projects. Each piece showcases our attention to detail and commitment to delivering results that exceed expectations.
            </p>
          </div>
        </section>

        {/* Passion / Split Image Section */}
        <section className="razor-split-section">
          {/* Left - Image */}
          <div className="razor-split-image">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src="https://primary.jwwb.nl/pexels/43/4348401.jpeg"
              alt="Designer working on creative marketing materials at a desk with colorful artwork"
              loading="lazy" />

          </div>

          {/* Right - Content */}
          <div className="razor-split-content">
            <h2 className="razor-section-heading">
              Our passion for marketing excellence
            </h2>
            <p className="razor-section-text">
              At Razor PC, our journey began with a simple idea: to support gaming with high-quality, effective, and innovative marketing solutions. As a Jacksonville-based company, we bring a personal touch to every project, with a strong focus on quality, attention to detail, and measurable results. We&nbsp;build&nbsp;our&nbsp;work&nbsp;on integrity, dedication, and a commitment to helping gaming brands grow with excellence.
            </p>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="razor-footer">
        <div className="razor-footer-inner">
          <div className="razor-footer-copyright">
            &copy; 2026 Razor PC
          </div>
          <div className="razor-footer-powered">
            Powered by <a href="https://www.webador.com" rel="nofollow">Webador</a>
          </div>
        </div>
      </footer>
    </div>);

}